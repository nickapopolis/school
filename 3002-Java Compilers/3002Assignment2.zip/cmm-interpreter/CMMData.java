
public abstract class CMMData {
}

public interface CMMiTokenizer{
  public CMMToken nextToken() throws CMMTokenizerException;
} // end CMMiTokenizer
